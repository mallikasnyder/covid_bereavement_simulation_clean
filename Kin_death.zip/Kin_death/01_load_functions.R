##Loading the functions we want to use

setwd("~/covid_simulation/Kin_death")

source("functions_bereavement.R")

# Data wrangling
wrangling <- c("tidyverse", "scales", "patchwork", "data.table","parallel", "knitr")

library2(wrangling)
